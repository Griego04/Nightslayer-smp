const host = 'nightslayersmp.aternos.me';
const toast = document.getElementById('toast');
let toastTimer;
function notify(message) {
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2200);
}
async function copyAddress() {
  try {
    await navigator.clipboard.writeText(host);
    notify('Server address copied!');
  } catch {
    const el = document.createElement('textarea');
    el.value = host; document.body.appendChild(el); el.select();
    document.execCommand('copy'); el.remove(); notify('Server address copied!');
  }
}
['copy-ip','copy-join','copy-bottom'].forEach(id => document.getElementById(id).addEventListener('click', copyAddress));
async function updateStatus() {
  const dot = document.getElementById('status-dot');
  const label = document.getElementById('status-text');
  const players = document.getElementById('player-count');
  try {
    const response = await fetch('/api/status', { cache: 'no-store' });
    if (!response.ok) throw new Error('Status unavailable');
    const data = await response.json();
    dot.className = 'status-dot ' + (data.online ? 'online' : 'offline');
    label.textContent = data.online ? 'Server reachable' : 'Server offline / sleeping';
    players.textContent = data.playersOnline == null ? '' : `${data.playersOnline}/${data.playersMax ?? '?'} players`;
    document.getElementById('server-port').textContent = data.port || '19132';
  } catch {
    dot.className = 'status-dot';
    label.textContent = 'Status API unavailable';
    players.textContent = 'Check Aternos directly';
  }
}
updateStatus();
setInterval(updateStatus, 60000);
