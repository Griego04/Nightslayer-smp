# NIGHTSLAYER SMP — Bedrock starter kit

A red-and-black static website plus a Bedrock status API and an optional Microsoft-authenticated Bedrock client.

## Important about Aternos
Your configured address is `nightslayersmp.aternos.me`. Bedrock servers commonly use UDP port `19132`, but Aternos may assign a different port; check **Aternos → Connect** and update `BEDROCK_PORT` below. The website status API checks the server but does not log in as a player.

Aternos explicitly prohibits bots/fake players and automated reconnecting intended to prevent the server's idle shutdown. Do **not** run the authenticated client against Aternos to keep it awake. Use the website/status monitor there, or run a player bot only on a host/server that permits it. Aternos may stop when nobody is playing; this kit does not bypass that.

## Requirements
- Node.js 20 or newer
- Aternos server started manually when you want to play
- Optional: Microsoft account with Minecraft Bedrock access for the authenticated client (only use on a server where you have permission)

## Run the website + status API
```bash
npm install
cp .env.example .env
npm start
```
Open http://localhost:3000. The site is static and the API runs at `/api/status`.
For a free static website, publish `public/` on GitHub Pages or Cloudflare Pages. Those static hosts do not run the Node status API; either deploy the API separately on a suitable Node host or remove the live status call and keep the address/copy button. Free hosting quotas and sleep policies can change.

## Microsoft-authenticated Bedrock client (optional)
This is separate from the website and status monitor. It uses `bedrock-protocol`'s Microsoft/Xbox authentication flow; on first run it prints a device-code sign-in prompt. Complete sign-in only on Microsoft's official page and never share the code or tokens.

1. Check the server owner's permission and the host's rules first.
2. Set `BOT_MODE=msa` and `BOT_ENABLED=true` in `.env`.
3. Run `npm run bot`.
4. Follow the device-code prompt in the terminal. Cached auth profiles are stored locally under `./auth-cache`; keep that directory private and never commit it.
5. Stop with Ctrl+C. The bot intentionally does not auto-reconnect endlessly.

The client may fail if the server is offline, the port/version is wrong, the server requires a different account setup, or the host blocks automated clients. Do not use it to evade idle timers.

## Two bot roles
- **Status bot**: checks server availability for the website; no Minecraft account required, does not join the world.
- **Microsoft-authenticated client**: optional real Bedrock client for permitted testing/administration; joins with your own Microsoft account. It is disabled by default.

## Security
- Never put Microsoft passwords, client secrets, or tokens in website JavaScript.
- `.env`, `auth-cache/`, and logs are excluded from Git.
- Never enter Microsoft credentials into a third-party website. The client uses device authentication and the library's local token cache.
