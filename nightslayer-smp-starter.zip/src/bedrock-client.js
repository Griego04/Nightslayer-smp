require('dotenv').config();
const path = require('path');
const bedrock = require('bedrock-protocol');

const enabled = String(process.env.BOT_ENABLED).toLowerCase() === 'true';
if (!enabled) {
  console.error('Client disabled. Set BOT_ENABLED=true only after checking server/host rules and getting permission.');
  process.exit(1);
}
if (String(process.env.BOT_MODE || 'msa').toLowerCase() !== 'msa') {
  console.error('This starter supports Microsoft-authenticated mode only.');
  process.exit(1);
}

const host = process.env.BEDROCK_HOST || 'nightslayersmp.aternos.me';
const port = Number(process.env.BEDROCK_PORT || 19132);
const username = process.env.BOT_USERNAME || 'NIGHTSLAYER_TestBot';
const profilesFolder = path.resolve(process.env.AUTH_CACHE_DIR || './auth-cache');

console.warn('Use only on a server where automated clients are permitted.');
console.warn('This client intentionally does not auto-reconnect or try to keep an idle server awake.');

const client = bedrock.createClient({
  host, port, username, profilesFolder,
  offline: false,
  onMsaCode: (data) => {
    console.log('\\nMicrosoft device sign-in required. Follow the URL and code shown below.');
    console.log('Complete sign-in only on the official Microsoft page.');
    console.log(data);
  }
});

client.on('join', () => console.log(`Connected to ${host}:${port} as ${username}.`));
client.on('spawn', () => console.log('Spawned in world.'));
client.on('kick', (reason) => console.log('Disconnected by server:', reason));
client.on('close', () => console.log('Connection closed. No automatic reconnect will be attempted.'));
client.on('error', (err) => console.error('Client error:', err.message));

process.on('SIGINT', () => {
  try { client.disconnect('NIGHTSLAYER test client stopping'); } catch {}
  process.exit(0);
});
