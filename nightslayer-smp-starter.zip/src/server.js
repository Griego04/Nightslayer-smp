require('dotenv').config();
const express = require('express');
const path = require('path');
const { ping } = require('bedrock-protocol');

const app = express();
const port = Number(process.env.PORT || 3000);
const host = process.env.BEDROCK_HOST || 'nightslayersmp.aternos.me';
const bedrockPort = Number(process.env.BEDROCK_PORT || 19132);

app.use(express.static(path.join(__dirname, '..', 'public')));
app.get('/api/status', async (_req, res) => {
  try {
    const result = await ping({ host, port: bedrockPort, timeout: 3500 });
    res.set('Cache-Control', 'no-store').json({
      online: true,
      host,
      port: bedrockPort,
      playersOnline: result?.players?.online ?? null,
      playersMax: result?.players?.max ?? null,
      version: result?.version ?? null,
      checkedAt: new Date().toISOString()
    });
  } catch {
    res.set('Cache-Control', 'no-store').status(200).json({
      online: false, host, port: bedrockPort,
      playersOnline: null, playersMax: null, version: null,
      checkedAt: new Date().toISOString(),
      note: 'Offline, sleeping, unreachable, or using a different port.'
    });
  }
});
app.listen(port, () => console.log(`NIGHTSLAYER site: http://localhost:${port}`));
